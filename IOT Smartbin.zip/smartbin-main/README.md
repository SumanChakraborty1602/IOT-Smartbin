# smartbin
Features:- Filled status mesurement using UltrasonicSensor, Auto Open-Close , Filled lock. ESP8266 enabled live status visualization in App interface. Admin interface for smart controls, Applied Dijkstra algorithm to calculate minimum cost maximum weight path on google map and route the Bins for easy maintenance.
